// AetherForge launcher — loads the compiled engine (bytecode).
// The engine logic ships as compiled V8 bytecode (*.jsc); this loader runs it.
require("./vendor/bytenode");
const fs = require("fs");
const path = require("path");
const jsc = fs.readdirSync(__dirname).find((f) => f.endsWith(".jsc"));
if (!jsc) { console.error("Engine file (.jsc) not found."); process.exit(1); }
require(path.join(__dirname, jsc));
