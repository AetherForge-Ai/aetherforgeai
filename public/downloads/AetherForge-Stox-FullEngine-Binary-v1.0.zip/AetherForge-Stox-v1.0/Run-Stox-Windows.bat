@echo off
REM AetherForge Stox launcher (Windows)
cd /d "%~dp0"
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo.
  echo Node.js is required. Please install the LTS version from https://nodejs.org
  echo then run this file again.
  echo.
  pause
  exit /b 1
)
node run.js %*
echo.
pause
