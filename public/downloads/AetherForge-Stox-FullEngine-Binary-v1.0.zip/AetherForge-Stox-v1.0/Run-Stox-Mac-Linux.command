#!/bin/bash
# AetherForge Stox launcher (macOS / Linux)
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo
  echo "Node.js is required. Please install the LTS version from https://nodejs.org"
  echo "then run this file again."
  echo
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
fi
node run.js "$@"
echo
read -n 1 -s -r -p "Done. Press any key to close..."
