# How to Use Your AetherForge Stox Bot

**Thank you for your purchase.** You now own a complete, self-hosted market
intelligence engine — the same technical engine that powers the AetherForge AI
website, delivered as a **compiled protected package** you run on your own
computer. It analyses stocks & shares (NZX, ASX and US markets).

Your engine is shipped as **compiled bytecode** (`stox.jsc`) — the original source
code is not included and cannot be read. You simply run it.

---

## 1. One-time setup (2 minutes)

The engine runs on **Node.js** (a free, safe runtime used by millions of apps).

1. Go to **https://nodejs.org** and download the **LTS** installer for your system.
2. Run the installer and accept the defaults.
3. That's it — you never need to touch the command line if you don't want to.

## 2. Add your portfolio

Open **`portfolio.csv`** (in this folder) with Excel, Numbers or any text editor
and enter your holdings — one per line:

```
ticker,quantity,avg_cost,purchase_date
AAPL,25,180.00,2024-01-15
FPH.NZ,100,28.50,2023-11-02
```

- **ticker** — the market symbol
- **quantity** — how many units you hold
- **avg_cost** — your average buy price
- **purchase_date** — optional (YYYY-MM-DD)

Save the file. (See `examples/` for a ready-made sample.)

## 3. Run the bot

**Windows:** double-click **`Run-Stox-Windows.bat`**

**Mac / Linux:** double-click **`Run-Stox-Mac-Linux.command`**
(the first time on a Mac you may need to right-click → Open to approve it)

Prefer the terminal? From this folder run:

```
node run.js
```

Useful options:

```
node run.js --portfolio myfile.csv   # use a different portfolio file
node run.js --offline                # skip the live-price refresh
```

## 4. Read your report

The bot writes a styled HTML report to the **`reports/`** folder, named with the
date. Double-click it to open it in your browser. You'll see:

- Your portfolio valuation and unrealised P&L
- High-conviction BUY ideas with plain-English reasoning
- A full market scan: price, 1D/7D moves, RSI, regime, conviction score,
  BUY / SELL / HOLD signal and a 7-day projection for every security

The engine runs **completely offline**. If you happen to be online it will
opportunistically refresh the latest price for the assets you hold; if not, it
uses its built-in model. No account, no subscription, no data leaves your machine.

---

*© Forge Intelligence Ltd. This software provides informational market
intelligence only and is not personalised financial advice. Markets carry risk.*
