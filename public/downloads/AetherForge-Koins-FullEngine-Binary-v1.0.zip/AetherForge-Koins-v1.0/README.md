# AetherForge Koins — Self-hosted crypto-market intelligence engine

Version 1.0.0 · Compiled protected package · One-time lifetime licence.

This package contains a **compiled** build of the AetherForge Koins engine
(`koins.jsc`, V8 bytecode). The original source code is not distributed.

## Contents

- `koins.jsc` .............. compiled intelligence engine (bytecode)
- `run.js` ............... launcher
- `Run-Koins-Windows.bat` .. double-click launcher for Windows
- `Run-Koins-Mac-Linux.command` double-click launcher for macOS / Linux
- `vendor/` ............. bundled runtime loader (zero third-party dependencies)
- `portfolio.csv` ....... your holdings (edit this)
- `examples/` ........... a sample portfolio
- `HOW-TO-USE.md` ....... full step-by-step guide

## Quick start

1. Install Node.js LTS from https://nodejs.org
2. Edit `portfolio.csv` with your holdings
3. Double-click the launcher for your platform (or run `node run.js`)
4. Open the generated report in `reports/`

See **HOW-TO-USE.md** for the complete guide.

Requires Node.js 18 or newer. Runs fully offline.
